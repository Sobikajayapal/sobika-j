package com.example.springexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
