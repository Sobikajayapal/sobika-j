package com.example.springexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringexampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringexampleApplication.class, args);
	}

}
